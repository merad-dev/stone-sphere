package com.zerocode.stone.sphere;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Random;

public class GameView extends View {

    static final float W = 720f;
    static final float R = 30f;
    static final float GRAV = 2300f;
    static final float JUMP = 1050f;
    static final float SPRING_V = 1650f;
    static final float WALL = 22f;
    static final float GROUND_H = 46f;
    static final float PLAT_H = 28f;
    static final float CARD_H = 340f;
    static final int INK = 0xFF23233A;
    static final int MENU = 0, PLAY = 1, DEAD = 2, STORE = 3;
    static final int[] DOODLE_COLORS = {0xFFC9CED8, 0xFFFFC9D6, 0xFFB9DDFF, 0xFFFFE08A, 0xFFB5EBC6};

    // ------------------------------------------------------------ stones
    static final String[] S_NAME = {
            "Pebble", "Sandstone", "Mossy Rock", "Red Brick", "Ice Stone",
            "Obsidian", "Lava Rock", "Wood Ball", "Rose Quartz", "Jade",
            "Gold Nugget", "Amethyst", "Galaxy", "Rainbow Opal", "Diamond"};
    static final int[] S_PRICE = {
            0, 25, 50, 80, 120,
            170, 230, 300, 400, 520,
            660, 820, 1000, 1250, 1600};
    static final int[] S_COLOR = {
            0xFFC7CBD6, 0xFFE8C98E, 0xFFA9BFA0, 0xFFE57B66, 0xFFBFEFFF,
            0xFF4A3F5E, 0xFF5A4038, 0xFFC8935A, 0xFFFFC2D6, 0xFF7ED9A6,
            0xFFFFD24D, 0xFFC59BFF, 0xFF2D3A78, 0xFFFFFFFF, 0xFFE6F6FF};

    static class Platform {
        float x, y, w, baseX, phase, amp, spd, dxFrame, springX, springComp, fallV;
        float crumble = -1f, alpha = 1f;
        int type, seed;
        boolean hasSpring, broken;
    }

    static class Coin { float x, y, phase; }

    static class Particle { float x, y, vx, vy, life, max, size, grav; int color; }

    static class Doodle { float x, yf, size, rot; int type, color; }

    // ------------------------------------------------------------- music
    static class Music implements Runnable {
        static final int SR = 22050;
        static final int[] ROOTS = {48, 45, 41, 43, 48, 45, 41, 43};
        static final boolean[] MINOR = {false, true, false, false, false, true, false, false};
        static final int[] ARP = {0, 1, 2, 1, 0, 1, 2, 1};
        static final int[] MEL = {
                76, -1, 79, -1, 76, -1, 74, -1,
                72, -1, 76, -1, 81, -1, 79, -1,
                81, -1, 79, -1, 77, -1, 76, -1,
                74, -1, 79, -1, 74, -1, -1, -1,
                79, -1, 81, -1, 79, -1, 76, -1,
                76, -1, 72, -1, 76, -1, 79, -1,
                77, -1, 76, -1, 74, -1, 72, -1,
                74, -1, 76, -1, 74, -1, -1, -1};

        volatile boolean running;
        volatile float vol = 0.6f;
        Thread th;

        void start() {
            if (running) return;
            running = true;
            th = new Thread(this);
            th.start();
        }

        void stop() {
            running = false;
            if (th != null) {
                try { th.join(800); } catch (InterruptedException ex) { }
                th = null;
            }
        }

        static double hz(int midi) {
            return 440.0 * Math.pow(2.0, (midi - 69) / 12.0);
        }

        public void run() {
            AudioTrack track = null;
            try {
                int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
                track = new AudioTrack(AudioManager.STREAM_MUSIC, SR, AudioFormat.CHANNEL_OUT_MONO,
                        AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192), AudioTrack.MODE_STREAM);
                track.play();
                short[] buf = new short[1024];
                final int stepN = (int) (SR * 60.0 / 104.0 / 2.0);
                final double stepT = stepN / (double) SR;
                long n = 0;
                int seed = 12345;
                final double TWO_PI = Math.PI * 2.0;
                while (running) {
                    track.setVolume(vol);
                    for (int i = 0; i < buf.length; i++, n++) {
                        int step = (int) ((n / stepN) % 64);
                        double t = (n % stepN) / (double) SR;
                        double ta = n / (double) SR;
                        int bar = step / 8, sb = step % 8;
                        int root = ROOTS[bar];
                        int third = MINOR[bar] ? 3 : 4;
                        int[] tones = {0, third, 7};
                        double s = 0.0;

                        // arpeggio
                        int an = root + 12 + tones[ARP[sb]];
                        double af = hz(an);
                        double ae = Math.min(1.0, t / 0.004) * Math.exp(-t * 12.0);
                        s += 0.15 * ae * (Math.sin(TWO_PI * af * ta) + 0.25 * Math.sin(2 * TWO_PI * af * ta));

                        // melody
                        int mn = MEL[step];
                        double mt = t;
                        if (mn < 0) {
                            mn = MEL[(step + 63) % 64];
                            mt = t + stepT;
                        }
                        if (mn >= 0) {
                            double mf = hz(mn);
                            double me = Math.min(1.0, mt / 0.006) * Math.exp(-mt * 6.5);
                            s += 0.2 * me * (Math.sin(TWO_PI * mf * ta) + 0.3 * Math.sin(2 * TWO_PI * mf * ta));
                        }

                        // bass (triangle)
                        double tb = (sb % 4) * stepT + t;
                        double bf = hz(root);
                        double x = bf * ta;
                        double tri = 2.0 * Math.abs(2.0 * (x - Math.floor(x + 0.5))) - 1.0;
                        s += 0.2 * tri * Math.min(1.0, tb / 0.005) * Math.exp(-tb * 3.0);

                        // kick
                        if ((sb == 0 || sb == 4) && t < 0.15) {
                            double ph = 50.0 * t + 2.333 * (1.0 - Math.exp(-30.0 * t));
                            s += 0.28 * Math.sin(TWO_PI * ph) * Math.exp(-t * 22.0);
                        }
                        // hat
                        if ((sb % 2 == 1) && t < 0.04) {
                            seed = seed * 1103515245 + 12345;
                            double nz = ((seed >> 16) & 0x7fff) / 16384.0 - 1.0;
                            s += 0.07 * nz * Math.exp(-t * 90.0);
                        }
                        s *= 0.85;
                        if (s > 1.0) s = 1.0;
                        if (s < -1.0) s = -1.0;
                        buf[i] = (short) (s * 32000.0);
                    }
                    track.write(buf, 0, buf.length);
                }
            } catch (Throwable ex) {
                // audio not available, ignore
            } finally {
                if (track != null) {
                    try { track.stop(); } catch (Throwable ex) { }
                    try { track.release(); } catch (Throwable ex) { }
                }
            }
        }
    }

    // ------------------------------------------------------------ fields
    final ArrayList<Platform> plats = new ArrayList<Platform>();
    final ArrayList<Coin> coinList = new ArrayList<Coin>();
    final ArrayList<Particle> parts = new ArrayList<Particle>();
    final Doodle[] doodles = new Doodle[26];
    final float[] stoneR = new float[14];
    final float[] hsv = new float[3];

    final Paint ink = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint thin = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint pat = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint pencil = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint grid = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint textP = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Path wp = new Path();
    final Path dp = new Path();
    final Path stonePath = new Path();
    final RectF rect = new RectF();
    final RectF tmpR = new RectF();
    final RectF bPlay = new RectF(), bStore = new RectF(), bSet = new RectF(), bMenu = new RectF();
    final RectF panel = new RectF(), listR = new RectF(), popup = new RectF();
    final Random rnd = new Random();
    final SharedPreferences prefs;
    final Music music = new Music();

    float sliderL, sliderR, sliderY, closeSX, closeSY, storeCX, storeCY;

    float H = 1400f, scale = 1f;
    int state = MENU;
    long lastNs = 0, lastEvT = 0;
    float time, scroll, topY, playTime, deadTimer, shake;

    float bx, by, bvx, bvy, bAngle, squash, coyote, jumpBuf;
    boolean grounded, touching, newBest, lastCrumble;
    Platform standing;
    float touchX;
    float climbed;
    int coins, best, totalCoins;

    int skin, unlocked;
    float vol;
    boolean showSettings, fingerDown, moved, draggingSlider, tapArmed;
    float downX, downY, lastY, storeScroll, storeVel, msgT, coinShake;
    String msg = "";

    public GameView(Context ctx) {
        super(ctx);
        prefs = ctx.getSharedPreferences("stone_sphere", Context.MODE_PRIVATE);
        best = prefs.getInt("best", 0);
        totalCoins = prefs.getInt("coins", 0);
        unlocked = prefs.getInt("unlocked", 1) | 1;
        skin = prefs.getInt("skin", 0);
        if (skin < 0 || skin >= S_NAME.length || (unlocked & (1 << skin)) == 0) skin = 0;
        vol = prefs.getFloat("vol", 0.6f);
        music.vol = vol;

        ink.setStyle(Paint.Style.STROKE);
        ink.setStrokeCap(Paint.Cap.ROUND);
        ink.setStrokeJoin(Paint.Join.ROUND);
        ink.setStrokeWidth(5f);
        ink.setColor(INK);
        thin.setStyle(Paint.Style.STROKE);
        thin.setStrokeCap(Paint.Cap.ROUND);
        thin.setStrokeJoin(Paint.Join.ROUND);
        thin.setStrokeWidth(2.5f);
        thin.setColor(INK);
        pat.setStyle(Paint.Style.STROKE);
        pat.setStrokeCap(Paint.Cap.ROUND);
        pat.setStrokeJoin(Paint.Join.ROUND);
        pat.setStrokeWidth(3f);
        pencil.setStyle(Paint.Style.STROKE);
        pencil.setStrokeCap(Paint.Cap.ROUND);
        pencil.setStrokeJoin(Paint.Join.ROUND);
        pencil.setStrokeWidth(3.5f);
        grid.setStyle(Paint.Style.STROKE);
        grid.setStrokeWidth(2f);
        grid.setColor(0xFFEFF2F8);
        fill.setStyle(Paint.Style.FILL);
        textP.setStyle(Paint.Style.FILL);
        textP.setTypeface(Typeface.create("casual", Typeface.BOLD));

        for (int i = 0; i < stoneR.length; i++) stoneR[i] = R * (0.9f + rnd.nextFloat() * 0.14f);
        for (int i = 0; i < stoneR.length; i++) {
            double a = i * Math.PI * 2.0 / stoneR.length;
            float px = (float) Math.cos(a) * stoneR[i], py = (float) Math.sin(a) * stoneR[i];
            if (i == 0) stonePath.moveTo(px, py); else stonePath.lineTo(px, py);
        }
        stonePath.close();

        for (int i = 0; i < doodles.length; i++) {
            Doodle d = new Doodle();
            d.x = 30f + rnd.nextFloat() * (W - 60f);
            d.yf = rnd.nextFloat();
            d.size = 18f + rnd.nextFloat() * 26f;
            d.rot = rnd.nextFloat() * 60f - 30f;
            d.type = rnd.nextInt(9);
            d.color = rnd.nextInt(DOODLE_COLORS.length);
            doodles[i] = d;
        }
        computeLayout();
        resetWorld();
        state = MENU;
    }

    // ------------------------------------------------------ life cycle

    public void resume() {
        music.vol = vol;
        music.start();
        lastNs = System.nanoTime();
        invalidate();
    }

    public void pause() {
        music.stop();
        saveAll();
    }

    @Override
    protected void onDetachedFromWindow() {
        music.stop();
        super.onDetachedFromWindow();
    }

    public boolean handleBack() {
        if (showSettings) {
            showSettings = false;
            saveAll();
            return true;
        }
        if (state == STORE) {
            state = MENU;
            return true;
        }
        if (state == PLAY || state == DEAD) {
            resetWorld();
            state = MENU;
            return true;
        }
        return false;
    }

    void saveAll() {
        prefs.edit().putInt("best", best).putInt("coins", totalCoins)
                .putInt("unlocked", unlocked).putInt("skin", skin)
                .putFloat("vol", vol).apply();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        scale = w / W;
        H = h / scale;
        computeLayout();
        if (state == MENU) resetWorld();
    }

    void computeLayout() {
        float cx = W / 2f;
        float by0 = H * 0.33f;
        bPlay.set(cx - 190f, by0, cx + 190f, by0 + 110f);
        bStore.set(cx - 190f, by0 + 140f, cx + 190f, by0 + 236f);
        bSet.set(cx - 190f, by0 + 266f, cx + 190f, by0 + 362f);
        bMenu.set(cx - 130f, H * 0.72f, cx + 130f, H * 0.72f + 86f);
        panel.set(24f, 70f, W - 24f, H - 70f);
        listR.set(panel.left + 6f, panel.top + 170f, panel.right - 6f, panel.bottom - 16f);
        storeCX = panel.right - 14f;
        storeCY = panel.top + 14f;
        popup.set(cx - 290f, H / 2f - 210f, cx + 290f, H / 2f + 210f);
        closeSX = popup.right - 6f;
        closeSY = popup.top + 6f;
        sliderL = popup.left + 60f;
        sliderR = popup.right - 60f;
        sliderY = popup.top + 280f;
    }

    // ---------------------------------------------------------- stones

    boolean owned(int i) {
        return (unlocked & (1 << i)) != 0;
    }

    boolean isDark(int sk) {
        return sk == 5 || sk == 6 || sk == 12;
    }

    int skinColor(int sk) {
        if (sk == 13) {
            hsv[0] = (time * 70f) % 360f;
            hsv[1] = 0.4f;
            hsv[2] = 1f;
            return Color.HSVToColor(hsv);
        }
        return S_COLOR[sk];
    }

    int trailColor(int sk) {
        switch (sk) {
            case 4: return 0xFFBFEFFF;
            case 6: return 0xFFFF8A00;
            case 10: return 0xFFFFD24D;
            case 12: return 0xFFB9A8FF;
            case 13: return skinColor(13);
            case 14: return 0xFF9ADCFF;
            default: return 0;
        }
    }

    void actionOnSkin(int i, float px, float py) {
        if (owned(i)) {
            skin = i;
            saveAll();
        } else if (totalCoins >= S_PRICE[i]) {
            totalCoins -= S_PRICE[i];
            unlocked |= (1 << i);
            skin = i;
            msg = "Unlocked " + S_NAME[i] + "!";
            msgT = 1.8f;
            emit(px, py, 18, 380f, 0xFFFFC93C, 9f, 400f, 0.8f, 100f);
            saveAll();
        } else {
            msg = "Not enough coins";
            msgT = 1.6f;
            coinShake = 0.45f;
        }
    }

    // ----------------------------------------------------------- world

    float diff() {
        return Math.min(1f, climbed / 7000f);
    }

    void resetWorld() {
        plats.clear();
        coinList.clear();
        parts.clear();
        Platform p = new Platform();
        p.w = 270f;
        p.x = (W - p.w) / 2f;
        p.y = H * 0.72f;
        p.baseX = p.x;
        p.type = 0;
        p.seed = rnd.nextInt(1000);
        plats.add(p);
        topY = p.y;
        bx = W / 2f;
        by = p.y - R;
        bvx = 0f;
        bvy = 0f;
        bAngle = 0f;
        squash = 0f;
        standing = p;
        grounded = true;
        coyote = 0.1f;
        jumpBuf = 0f;
        climbed = 0f;
        coins = 0;
        playTime = 0f;
        scroll = 0f;
        lastCrumble = false;
        newBest = false;
        touching = false;
        while (topY > -160f) spawnPlatform();
    }

    void spawnPlatform() {
        float d = diff();
        topY -= 115f + rnd.nextFloat() * (45f + 35f * d);
        Platform p = new Platform();
        int r = rnd.nextInt(100);
        p.type = 0;
        if (r < 12 + 18 * d) p.type = 1;
        else if (r < 28 + 22 * d && !lastCrumble) p.type = 2;
        lastCrumble = (p.type == 2);
        p.w = 150f + rnd.nextFloat() * 90f - 40f * d;
        p.x = WALL + 14f + rnd.nextFloat() * (W - 2f * (WALL + 14f) - p.w);
        p.y = topY;
        p.baseX = p.x;
        p.phase = rnd.nextFloat() * 6.28f;
        p.seed = rnd.nextInt(10000);
        if (p.type == 1) {
            float avail = Math.min(p.baseX - (WALL + 14f), W - (WALL + 14f) - (p.baseX + p.w));
            p.amp = Math.min(avail, 90f);
            p.spd = 1.2f + rnd.nextFloat() * 1.2f;
            if (p.amp < 25f) p.type = 0;
        }
        if (p.type == 0 && rnd.nextInt(100) < 14) {
            p.hasSpring = true;
            p.springX = 36f + rnd.nextFloat() * (p.w - 72f);
        }
        plats.add(p);
        if (rnd.nextInt(100) < 55) {
            int n = 1 + rnd.nextInt(3);
            float cy = p.y - 75f - rnd.nextFloat() * 20f;
            for (int i = 0; i < n; i++) {
                Coin k = new Coin();
                float cx = p.x + p.w / 2f + (i - (n - 1) / 2f) * 52f;
                k.x = Math.max(WALL + 30f, Math.min(W - WALL - 30f, cx));
                k.y = cy - (n > 1 ? (float) Math.sin(i * Math.PI / (n - 1)) * 30f : 0f);
                k.phase = rnd.nextFloat() * 6f;
                coinList.add(k);
            }
        }
    }

    void shiftWorld(float dy) {
        for (Platform p : plats) p.y += dy;
        for (Coin k : coinList) k.y += dy;
        for (Particle q : parts) q.y += dy;
        topY += dy;
        scroll += dy;
    }

    void emit(float x, float y, int n, float speed, int color, float size, float grav, float life, float upBias) {
        for (int i = 0; i < n && parts.size() < 260; i++) {
            Particle p = new Particle();
            double a = rnd.nextDouble() * Math.PI * 2.0;
            float sp = speed * (0.3f + rnd.nextFloat() * 0.7f);
            p.x = x;
            p.y = y;
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp - upBias;
            p.life = life * (0.6f + rnd.nextFloat() * 0.4f);
            p.max = p.life;
            p.size = size * (0.6f + rnd.nextFloat() * 0.8f);
            p.grav = grav;
            p.color = color;
            parts.add(p);
        }
    }

    void die() {
        state = DEAD;
        deadTimer = 0f;
        shake = 0.5f;
        touching = false;
        int m = (int) (climbed / 40f);
        newBest = m > best;
        if (newBest) best = m;
        totalCoins += coins;
        saveAll();
        emit(bx, by, 26, 520f, skinColor(skin), 11f, 1500f, 1.2f, 150f);
        emit(bx, by, 12, 420f, INK, 6f, 1500f, 1.0f, 150f);
    }

    // ---------------------------------------------------------- update

    float maxScroll() {
        float content = 8f * (CARD_H + 24f) + 10f;
        return Math.max(0f, content - listR.height());
    }

    void clampStore() {
        float mx = maxScroll();
        if (storeScroll < 0f) {
            storeScroll = 0f;
            storeVel = 0f;
        }
        if (storeScroll > mx) {
            storeScroll = mx;
            storeVel = 0f;
        }
    }

    void update(float dt) {
        if (msgT > 0f) msgT -= dt;
        if (coinShake > 0f) coinShake -= dt;
        if (state == PLAY) updatePlay(dt);
        else if (state == MENU) {
            squash = 0.12f * (float) Math.sin(time * 3f);
            scroll += 20f * dt;
        } else if (state == DEAD) deadTimer += dt;
        else if (state == STORE) {
            scroll += 10f * dt;
            if (!fingerDown) {
                if (Math.abs(storeVel) > 15f) {
                    storeScroll += storeVel * dt;
                    storeVel *= Math.max(0f, 1f - 4f * dt);
                    clampStore();
                } else {
                    storeVel = 0f;
                }
            }
        }

        for (int i = parts.size() - 1; i >= 0; i--) {
            Particle p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0f) {
                parts.remove(i);
                continue;
            }
            p.vy += p.grav * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
        }
    }

    void updatePlay(float dt) {
        playTime += dt;
        float sk = (45f + 125f * diff()) * Math.min(1f, playTime / 2.5f);

        for (int i = plats.size() - 1; i >= 0; i--) {
            Platform p = plats.get(i);
            p.y += sk * dt;
            float ox = p.x;
            if (p.type == 1) p.x = p.baseX + (float) Math.sin(time * p.spd + p.phase) * p.amp;
            p.dxFrame = p.x - ox;
            if (p.crumble >= 0f && !p.broken) {
                p.crumble += dt;
                if (p.crumble > 0.55f) {
                    p.broken = true;
                    emit(p.x + p.w / 2f, p.y + 10f, 10, 200f, 0xFFFFD08A, 9f, 900f, 0.7f, 0f);
                }
            }
            if (p.broken) {
                p.fallV += GRAV * dt;
                p.y += p.fallV * dt;
                p.alpha -= dt * 1.6f;
            }
            if (p.springComp > 0f) p.springComp = Math.max(0f, p.springComp - dt * 3.5f);
            if (p.y > H + 150f || p.alpha <= 0f) plats.remove(i);
        }
        for (int i = coinList.size() - 1; i >= 0; i--) {
            Coin k = coinList.get(i);
            k.y += sk * dt;
            if (k.y > H + 60f) coinList.remove(i);
        }
        topY += sk * dt;
        scroll += sk * dt;

        jumpBuf -= dt;
        coyote -= dt;
        float prevBottom = by + R;

        if (touching) {
            float ax = (touchX - bx) * 16f;
            if (ax > 3200f) ax = 3200f;
            if (ax < -3200f) ax = -3200f;
            bvx += ax * dt;
        }
        float damp = touching ? (grounded ? 4f : 1.2f) : (grounded ? 7f : 1.5f);
        bvx -= bvx * Math.min(1f, damp * dt);
        if (bvx > 720f) bvx = 720f;
        if (bvx < -720f) bvx = -720f;

        bvy += GRAV * (bvy > 0f ? 1.2f : 1f) * dt;
        if (bvy > 1500f) bvy = 1500f;

        if (standing != null && grounded && !standing.broken) bx += standing.dxFrame;
        bx += bvx * dt;
        by += bvy * dt;
        bAngle += bvx * dt / R;

        grounded = false;
        boolean sprung = false;
        if (bvy >= 0f) {
            for (Platform p : plats) {
                if (p.broken || !p.hasSpring) continue;
                float st = p.y - 30f;
                float pst = st - sk * dt;
                float sx = p.x + p.springX;
                if (by + R >= st - 3f && prevBottom <= pst + 10f && Math.abs(bx - sx) < 36f) {
                    by = st - R;
                    bvy = -SPRING_V;
                    p.springComp = 1f;
                    squash = -0.8f;
                    standing = null;
                    coyote = 0f;
                    sprung = true;
                    emit(sx, st, 12, 260f, 0xFFFF8A8A, 8f, 600f, 0.5f, 100f);
                    break;
                }
            }
        }
        if (!sprung && bvy >= 0f) {
            Platform hit = null;
            for (Platform p : plats) {
                if (p.broken) continue;
                float prevTop = p.y - sk * dt;
                if (by + R >= p.y - 3f && prevBottom <= prevTop + 10f
                        && bx > p.x - R * 0.5f && bx < p.x + p.w + R * 0.5f) {
                    if (hit == null || p.y < hit.y) hit = p;
                }
            }
            if (hit != null) {
                by = hit.y - R;
                if (bvy > 300f) {
                    squash = Math.min(1f, bvy / 1200f);
                    emit(bx, by + R, 6, 160f, 0xFFD5D8E2, 9f, 0f, 0.45f, 0f);
                }
                bvy = 0f;
                grounded = true;
                coyote = 0.1f;
                standing = hit;
                if (hit.type == 2 && hit.crumble < 0f) hit.crumble = 0f;
            } else {
                standing = null;
            }
        }

        if (jumpBuf > 0f && (grounded || coyote > 0f)) {
            bvy = -JUMP;
            jumpBuf = 0f;
            coyote = 0f;
            grounded = false;
            standing = null;
            squash = -0.6f;
            emit(bx, by + R, 5, 140f, 0xFFD5D8E2, 8f, 0f, 0.4f, 0f);
        }
        squash -= squash * Math.min(1f, 10f * dt);

        int tc = trailColor(skin);
        if (tc != 0 && rnd.nextInt(100) < 35) {
            emit(bx + (rnd.nextFloat() - 0.5f) * 30f, by + (rnd.nextFloat() - 0.5f) * 30f,
                    1, 30f, tc, 5f, 0f, 0.5f, 0f);
        }

        float camY = H * 0.42f;
        if (by < camY) {
            float dy = camY - by;
            by = camY;
            shiftWorld(dy);
            climbed += dy;
        }
        while (topY > -160f) spawnPlatform();

        for (int i = coinList.size() - 1; i >= 0; i--) {
            Coin k = coinList.get(i);
            float dx = k.x - bx, dy = k.y - by;
            if (dx * dx + dy * dy < (R + 20f) * (R + 20f)) {
                coinList.remove(i);
                coins++;
                emit(k.x, k.y, 8, 260f, 0xFFFFC93C, 7f, 300f, 0.5f, 60f);
            }
        }

        if (by + R > H - GROUND_H + 10f || bx - R < 8f || bx + R > W - 8f) die();
    }

    // ----------------------------------------------------------- touch

    void setVolumeFromX(float x) {
        float v = (x - sliderL) / (sliderR - sliderL);
        if (v < 0f) v = 0f;
        if (v > 1f) v = 1f;
        vol = v;
        music.vol = v;
    }

    boolean hitClose(float x, float y, float cx, float cy) {
        float dx = x - cx, dy = y - cy;
        return dx * dx + dy * dy < 46f * 46f;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();

        if (state == PLAY && !showSettings) {
            if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
                touching = true;
                touchX = e.getX(e.getActionIndex()) / scale;
                jumpBuf = 0.14f;
            } else if (a == MotionEvent.ACTION_MOVE) {
                touchX = e.getX(e.getPointerCount() - 1) / scale;
            } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                touching = false;
            } else if (a == MotionEvent.ACTION_POINTER_UP) {
                touching = e.getPointerCount() > 2;
            }
            return true;
        }

        float x = e.getX() / scale, y = e.getY() / scale;
        if (a == MotionEvent.ACTION_DOWN) {
            fingerDown = true;
            tapArmed = true;
            moved = false;
            downX = x;
            downY = y;
            lastY = y;
            lastEvT = e.getEventTime();
            storeVel = 0f;
            if (showSettings && Math.abs(y - sliderY) < 60f && x > sliderL - 30f && x < sliderR + 30f) {
                draggingSlider = true;
                setVolumeFromX(x);
            }
        } else if (a == MotionEvent.ACTION_MOVE) {
            if (Math.abs(x - downX) > 18f || Math.abs(y - downY) > 18f) moved = true;
            if (draggingSlider) {
                setVolumeFromX(x);
            } else if (state == STORE && !showSettings && moved) {
                float dy = y - lastY;
                storeScroll -= dy;
                float dtS = (e.getEventTime() - lastEvT) / 1000f;
                if (dtS > 0.001f) {
                    float v = -dy / dtS;
                    if (v > 5000f) v = 5000f;
                    if (v < -5000f) v = -5000f;
                    storeVel = storeVel * 0.5f + v * 0.5f;
                }
                clampStore();
            }
            lastY = y;
            lastEvT = e.getEventTime();
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            fingerDown = false;
            if (draggingSlider) {
                draggingSlider = false;
                saveAll();
            } else if (a == MotionEvent.ACTION_UP && tapArmed && !moved) {
                onTap(x, y);
            }
            tapArmed = false;
        }
        return true;
    }

    void onTap(float x, float y) {
        if (showSettings) {
            if (hitClose(x, y, closeSX, closeSY)) {
                showSettings = false;
                saveAll();
            }
            return;
        }
        if (state == MENU) {
            if (bPlay.contains(x, y)) {
                state = PLAY;
                playTime = 0f;
            } else if (bStore.contains(x, y)) {
                state = STORE;
                storeScroll = 0f;
                storeVel = 0f;
            } else if (bSet.contains(x, y)) {
                showSettings = true;
            }
        } else if (state == STORE) {
            if (hitClose(x, y, storeCX, storeCY)) {
                state = MENU;
                return;
            }
            if (!listR.contains(x, y)) return;
            float gap = 24f;
            float cw = (panel.width() - 3f * gap) / 2f;
            for (int i = 0; i < S_NAME.length; i++) {
                float cx0 = panel.left + gap + (i % 2) * (cw + gap);
                float cy0 = listR.top + 10f + (i / 2) * (CARD_H + gap) - storeScroll;
                tmpR.set(cx0 + 20f, cy0 + CARD_H - 86f, cx0 + cw - 20f, cy0 + CARD_H - 22f);
                if (tmpR.contains(x, y)) {
                    actionOnSkin(i, tmpR.centerX(), tmpR.centerY());
                    return;
                }
            }
        } else if (state == DEAD) {
            if (deadTimer < 0.6f) return;
            if (bMenu.contains(x, y)) {
                resetWorld();
                state = MENU;
            } else {
                resetWorld();
                state = PLAY;
            }
        }
    }

    // ------------------------------------------------------------ draw

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = (now - lastNs) / 1e9f;
        lastNs = now;
        if (dt > 0.033f) dt = 0.033f;
        if (dt < 0f) dt = 0f;
        time += dt;
        update(dt);

        c.drawColor(Color.WHITE);
        c.save();
        c.scale(scale, scale);
        if (shake > 0f) {
            shake -= dt;
            c.translate((rnd.nextFloat() - 0.5f) * shake * 40f, (rnd.nextFloat() - 0.5f) * shake * 40f);
        }
        drawBackground(c);
        if (state != STORE) {
            drawWalls(c);
            drawGround(c);
            for (Platform p : plats) drawPlatform(c, p);
            for (Coin k : coinList) drawCoin(c, k);
            if (state != DEAD) drawBall(c);
        } else {
            drawStore(c);
        }
        drawParticles(c);
        if (state == PLAY || state == DEAD) drawHud(c);
        if (state == MENU) drawMenu(c);
        if (state == DEAD) drawDead(c);
        if (showSettings) drawSettings(c);
        c.restore();
        postInvalidateOnAnimation();
    }

    void text(Canvas c, String s, float x, float y, float size, int color, Paint.Align al) {
        textP.setColor(color);
        textP.setTextSize(size);
        textP.setTextAlign(al);
        c.drawText(s, x, y, textP);
    }

    static float noise(int n) {
        n = (n << 13) ^ n;
        return 1f - ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 1073741824f;
    }

    void wobbleRect(float l, float t, float r, float b, int seed) {
        int k = 0;
        wp.reset();
        wp.moveTo(l + noise(seed * 131 + (k++) * 17) * 2.5f, t + noise(seed * 131 + (k++) * 17) * 2.5f);
        for (float x = l; x < r; x += 40f)
            wp.lineTo(Math.min(x + 40f, r) + noise(seed * 131 + (k++) * 17) * 2.5f, t + noise(seed * 131 + (k++) * 17) * 2.5f);
        for (float y = t; y < b; y += 40f)
            wp.lineTo(r + noise(seed * 131 + (k++) * 17) * 2.5f, Math.min(y + 40f, b) + noise(seed * 131 + (k++) * 17) * 2.5f);
        for (float x = r; x > l; x -= 40f)
            wp.lineTo(Math.max(x - 40f, l) + noise(seed * 131 + (k++) * 17) * 2.5f, b + noise(seed * 131 + (k++) * 17) * 2.5f);
        for (float y = b; y > t; y -= 40f)
            wp.lineTo(l + noise(seed * 131 + (k++) * 17) * 2.5f, Math.max(y - 40f, t) + noise(seed * 131 + (k++) * 17) * 2.5f);
        wp.close();
    }

    void drawButton(Canvas c, RectF r, String label, int col, float size) {
        fill.setColor(col);
        rect.set(r.left + 6f, r.top + 6f, r.right + 6f, r.bottom + 6f);
        c.drawRoundRect(rect, 20f, 20f, fill);
        c.drawRoundRect(r, 20f, 20f, ink);
        if (label.length() > 0)
            text(c, label, r.centerX(), r.centerY() + size * 0.35f, size, INK, Paint.Align.CENTER);
    }

    void drawClose(Canvas c, float cx, float cy) {
        fill.setColor(0xFFFF5252);
        c.drawCircle(cx, cy, 34f, fill);
        c.drawCircle(cx, cy, 34f, ink);
        pat.setColor(0xFFFFFFFF);
        pat.setStrokeWidth(7f);
        c.drawLine(cx - 12f, cy - 12f, cx + 12f, cy + 12f, pat);
        c.drawLine(cx + 12f, cy - 12f, cx - 12f, cy + 12f, pat);
        pat.setStrokeWidth(3f);
    }

    void drawBackground(Canvas c) {
        for (float x = 0; x <= W; x += 72f) c.drawLine(x, 0, x, H, grid);
        float off = (scroll * 0.5f) % 72f;
        for (float y = off - 72f; y <= H; y += 72f) c.drawLine(0, y, W, y, grid);
        float P = H + 200f;
        for (Doodle d : doodles) {
            float y = ((d.yf * P + scroll * 0.3f) % P) - 100f;
            drawDoodle(c, d, y);
        }
    }

    void drawDoodle(Canvas c, Doodle d, float y) {
        int col = DOODLE_COLORS[d.color];
        pencil.setColor(col);
        float s = d.size;
        c.save();
        c.translate(d.x, y);
        c.rotate(d.rot);
        switch (d.type) {
            case 0:
                dp.reset();
                for (int i = 0; i < 10; i++) {
                    double a = Math.toRadians(-90 + i * 36);
                    float r = (i % 2 == 0) ? s : s * 0.45f;
                    float px = (float) Math.cos(a) * r, py = (float) Math.sin(a) * r;
                    if (i == 0) dp.moveTo(px, py); else dp.lineTo(px, py);
                }
                dp.close();
                c.drawPath(dp, pencil);
                break;
            case 1:
                dp.reset();
                for (float t = 0f; t < 18f; t += 0.4f) {
                    float r = s * t / 18f;
                    float px = (float) Math.cos(t) * r, py = (float) Math.sin(t) * r;
                    if (t == 0f) dp.moveTo(px, py); else dp.lineTo(px, py);
                }
                c.drawPath(dp, pencil);
                break;
            case 2:
                dp.reset();
                dp.moveTo(0, s * 0.35f);
                dp.cubicTo(-s, -s * 0.3f, -s * 0.4f, -s * 0.9f, 0, -s * 0.35f);
                dp.cubicTo(s * 0.4f, -s * 0.9f, s, -s * 0.3f, 0, s * 0.35f);
                c.drawPath(dp, pencil);
                break;
            case 3:
                dp.reset();
                for (int i = 0; i <= 8; i++) {
                    float px = -s + i * s / 4f;
                    float py = ((i % 2 == 0) ? -1f : 1f) * s * 0.25f;
                    if (i == 0) dp.moveTo(px, py); else dp.lineTo(px, py);
                }
                c.drawPath(dp, pencil);
                break;
            case 4:
                c.drawLine(-s * 0.7f, 0, s * 0.7f, 0, pencil);
                c.drawLine(0, -s * 0.7f, 0, s * 0.7f, pencil);
                break;
            case 5:
                c.drawCircle(0, 0, s * 0.6f, pencil);
                c.drawCircle(s * 0.06f, -s * 0.04f, s * 0.55f, pencil);
                break;
            case 6:
                dp.reset();
                dp.moveTo(-s, 0);
                dp.quadTo(0, -s * 0.6f, s, 0);
                c.drawPath(dp, pencil);
                c.drawLine(s, 0, s - 12f, -10f, pencil);
                c.drawLine(s, 0, s - 6f, 12f, pencil);
                break;
            case 7:
                fill.setColor(col);
                c.drawCircle(-s * 0.5f, 0, 4f, fill);
                c.drawCircle(0, -s * 0.2f, 5f, fill);
                c.drawCircle(s * 0.5f, s * 0.1f, 4f, fill);
                break;
            default:
                dp.reset();
                dp.moveTo(0, -s * 0.8f);
                dp.lineTo(s * 0.8f, s * 0.6f);
                dp.lineTo(-s * 0.8f, s * 0.6f);
                dp.close();
                c.drawPath(dp, pencil);
                break;
        }
        c.restore();
    }

    void drawWalls(Canvas c) {
        float off = scroll % 64f;
        wp.reset();
        wp.moveTo(-10f, off - 70f);
        for (float y = off - 64f; y < H + 64f; y += 64f) {
            wp.lineTo(2f, y);
            wp.lineTo(WALL, y + 32f);
        }
        wp.lineTo(2f, H + 130f);
        wp.lineTo(-10f, H + 130f);
        wp.close();
        for (int side = 0; side < 2; side++) {
            c.save();
            if (side == 1) {
                c.translate(W, 0);
                c.scale(-1f, 1f);
            }
            fill.setColor(0xFFFF9C9C);
            c.save();
            c.translate(4f, 0f);
            c.drawPath(wp, fill);
            c.restore();
            c.drawPath(wp, ink);
            c.restore();
        }
    }

    void drawGround(Canvas c) {
        float gy = H - GROUND_H;
        dp.reset();
        dp.moveTo(-10f, H + 10f);
        dp.lineTo(-10f, gy + 22f);
        for (float x = -10f; x < W + 48f; x += 48f) {
            float w = (float) Math.sin(time * 3f + x * 0.1f) * 3f;
            dp.lineTo(x + 24f, gy + w);
            dp.lineTo(x + 48f, gy + 22f);
        }
        dp.lineTo(W + 60f, H + 10f);
        dp.close();
        fill.setColor(0xFFFF9C9C);
        c.save();
        c.translate(0f, 5f);
        c.drawPath(dp, fill);
        c.restore();
        c.drawPath(dp, ink);
    }

    void drawPlatform(Canvas c, Platform p) {
        if (p.alpha <= 0f) return;
        int al = (int) (255 * Math.min(1f, p.alpha));
        int col = p.type == 0 ? 0xFFFFB3C7 : (p.type == 1 ? 0xFF9AD0FF : 0xFFFFD08A);
        ink.setAlpha(al);
        thin.setAlpha(al);
        fill.setColor(col);
        fill.setAlpha(al);
        float sx = 0f;
        if (p.crumble >= 0f && !p.broken) sx = (float) Math.sin(time * 70f) * 3f * (p.crumble / 0.55f);
        c.save();
        c.translate(sx, 0f);
        rect.set(p.x + 6f, p.y + 6f, p.x + p.w + 6f, p.y + PLAT_H + 6f);
        c.drawRoundRect(rect, 10f, 10f, fill);
        wobbleRect(p.x, p.y, p.x + p.w, p.y + PLAT_H, p.seed);
        c.drawPath(wp, ink);
        float my = p.y + PLAT_H / 2f;
        if (p.type == 0) {
            for (float x = p.x + 16f; x < p.x + p.w - 14f; x += 24f)
                c.drawLine(x, p.y + PLAT_H - 7f, x + 11f, p.y + 7f, thin);
        } else if (p.type == 1) {
            c.drawLine(p.x + 20f, my - 7f, p.x + 12f, my, thin);
            c.drawLine(p.x + 12f, my, p.x + 20f, my + 7f, thin);
            c.drawLine(p.x + p.w - 20f, my - 7f, p.x + p.w - 12f, my, thin);
            c.drawLine(p.x + p.w - 12f, my, p.x + p.w - 20f, my + 7f, thin);
        } else {
            float mx = p.x + p.w / 2f;
            c.drawLine(mx - 30f, p.y + 5f, mx - 20f, my, thin);
            c.drawLine(mx - 20f, my, mx - 32f, p.y + PLAT_H - 4f, thin);
            c.drawLine(mx + 22f, p.y + 4f, mx + 12f, my + 2f, thin);
            c.drawLine(mx + 12f, my + 2f, mx + 26f, p.y + PLAT_H - 5f, thin);
        }
        if (p.hasSpring && !p.broken) {
            float sxp = p.x + p.springX;
            float hs = 30f * (1f - 0.6f * p.springComp);
            float top = p.y - hs;
            dp.reset();
            dp.moveTo(sxp, p.y - 4f);
            for (int i = 1; i <= 4; i++) {
                float yy = p.y - 4f - (hs - 8f) * i / 4f;
                dp.lineTo(sxp + ((i % 2 == 1) ? 11f : -11f), yy);
            }
            dp.lineTo(sxp, top);
            c.drawPath(dp, ink);
            fill.setColor(0xFFFF6B6B);
            fill.setAlpha(al);
            rect.set(sxp - 22f, top - 9f, sxp + 22f, top);
            c.drawRoundRect(rect, 5f, 5f, fill);
            c.drawRoundRect(rect, 5f, 5f, ink);
            rect.set(sxp - 15f, p.y - 6f, sxp + 15f, p.y);
            fill.setColor(INK);
            fill.setAlpha(al);
            c.drawRoundRect(rect, 3f, 3f, fill);
        }
        c.restore();
        ink.setAlpha(255);
        thin.setAlpha(255);
    }

    void drawCoinShape(Canvas c, float x, float y, float r, float w) {
        rect.set(x - r * w + 3f, y - r + 3f, x + r * w + 3f, y + r + 3f);
        fill.setColor(0xFFFFC93C);
        c.drawOval(rect, fill);
        rect.set(x - r * w, y - r, x + r * w, y + r);
        c.drawOval(rect, ink);
        if (w > 0.45f) c.drawLine(x, y - r * 0.45f, x, y + r * 0.45f, thin);
    }

    void drawCoin(Canvas c, Coin k) {
        float w = Math.max(0.18f, Math.abs((float) Math.cos(time * 4f + k.phase)));
        float y = k.y + (float) Math.sin(time * 3f + k.phase) * 4f;
        drawCoinShape(c, k.x, y, 19f, w);
    }

    // ------------------------------------------------------- stone art

    void drawStone(Canvas c, int sk, float ang) {
        float deg = (float) Math.toDegrees(ang);
        fill.setColor(skinColor(sk));
        c.save();
        c.translate(3f, 3f);
        c.rotate(deg);
        c.drawPath(stonePath, fill);
        c.save();
        c.clipPath(stonePath);
        drawPattern(c, sk);
        c.restore();
        c.restore();
        c.save();
        c.rotate(deg);
        c.drawPath(stonePath, ink);
        c.restore();
    }

    void sparkle(Canvas c, float x, float y, float s, int col) {
        pat.setColor(col);
        pat.setStrokeWidth(2.5f);
        c.drawLine(x - s, y, x + s, y, pat);
        c.drawLine(x, y - s, x, y + s, pat);
        pat.setStrokeWidth(3f);
    }

    void drawPattern(Canvas c, int sk) {
        pat.setStrokeWidth(3f);
        switch (sk) {
            case 0:
                pat.setColor(INK);
                pat.setStrokeWidth(2.5f);
                c.drawLine(-12f, -20f, -4f, -9f, pat);
                c.drawLine(-4f, -9f, -13f, 2f, pat);
                c.drawLine(14f, 8f, 7f, 16f, pat);
                c.drawLine(7f, 16f, 15f, 21f, pat);
                fill.setColor(INK);
                c.drawCircle(16f, -12f, 2.2f, fill);
                c.drawCircle(-18f, 12f, 2.2f, fill);
                c.drawCircle(4f, 20f, 1.8f, fill);
                c.drawCircle(-6f, -22f, 1.8f, fill);
                break;
            case 1:
                pat.setColor(0xFFB8935A);
                c.drawLine(-30f, -14f, 30f, -9f, pat);
                c.drawLine(-30f, 0f, 30f, 4f, pat);
                c.drawLine(-30f, 13f, 30f, 10f, pat);
                c.drawLine(-30f, 24f, 30f, 27f, pat);
                fill.setColor(0xFF9C7A45);
                c.drawCircle(-10f, -6f, 1.8f, fill);
                c.drawCircle(12f, 6f, 1.8f, fill);
                c.drawCircle(-4f, 18f, 1.8f, fill);
                break;
            case 2:
                fill.setColor(0xFF5FAE5A);
                c.drawCircle(-12f, -14f, 10f, fill);
                c.drawCircle(2f, -20f, 8f, fill);
                c.drawCircle(-20f, -2f, 7f, fill);
                c.drawCircle(14f, 14f, 6f, fill);
                fill.setColor(0xFF3E8A3F);
                c.drawCircle(-12f, -14f, 4f, fill);
                c.drawCircle(-20f, -2f, 3f, fill);
                pat.setColor(INK);
                c.drawLine(8f, -6f, 14f, 4f, pat);
                c.drawLine(14f, 4f, 8f, 12f, pat);
                break;
            case 3:
                pat.setColor(0xFFF4E3D0);
                c.drawLine(-30f, -12f, 30f, -12f, pat);
                c.drawLine(-30f, 6f, 30f, 6f, pat);
                c.drawLine(-30f, 22f, 30f, 22f, pat);
                c.drawLine(-8f, -30f, -8f, -12f, pat);
                c.drawLine(14f, -30f, 14f, -12f, pat);
                c.drawLine(-20f, -12f, -20f, 6f, pat);
                c.drawLine(2f, -12f, 2f, 6f, pat);
                c.drawLine(24f, -12f, 24f, 6f, pat);
                c.drawLine(-8f, 6f, -8f, 22f, pat);
                c.drawLine(14f, 6f, 14f, 22f, pat);
                c.drawLine(-20f, 22f, -20f, 30f, pat);
                c.drawLine(2f, 22f, 2f, 30f, pat);
                break;
            case 4:
                pat.setColor(0xFF7FC8E8);
                pat.setStrokeWidth(2.5f);
                c.drawLine(-22f, -8f, 0f, -26f, pat);
                c.drawLine(0f, -26f, 22f, -8f, pat);
                c.drawLine(0f, -26f, 0f, 2f, pat);
                c.drawLine(-22f, -8f, 0f, 2f, pat);
                c.drawLine(22f, -8f, 0f, 2f, pat);
                c.drawLine(-22f, 12f, 0f, 2f, pat);
                c.drawLine(22f, 12f, 0f, 2f, pat);
                c.drawLine(-8f, 28f, 0f, 2f, pat);
                c.drawLine(10f, 26f, 0f, 2f, pat);
                break;
            case 5:
                pat.setColor(0xFF8E6BD1);
                c.drawLine(-18f, 10f, -4f, -6f, pat);
                c.drawLine(6f, 18f, 20f, 2f, pat);
                pat.setColor(0xCCFFFFFF);
                pat.setStrokeWidth(4f);
                c.drawLine(-20f, -14f, -8f, -24f, pat);
                break;
            case 6:
                pat.setColor(0xFFFF8A00);
                pat.setStrokeWidth(4f);
                c.drawLine(-20f, -8f, -8f, 0f, pat);
                c.drawLine(-8f, 0f, -14f, 12f, pat);
                c.drawLine(-14f, 12f, -4f, 22f, pat);
                c.drawLine(6f, -18f, 12f, -6f, pat);
                c.drawLine(12f, -6f, 4f, 4f, pat);
                c.drawLine(4f, 4f, 16f, 14f, pat);
                fill.setColor(0xFFFFD24D);
                c.drawCircle(-8f, 0f, 2.5f, fill);
                c.drawCircle(12f, -6f, 2.5f, fill);
                break;
            case 7:
                pat.setColor(0xFF8A5A2B);
                c.drawCircle(6f, 2f, 9f, pat);
                c.drawCircle(6f, 2f, 18f, pat);
                c.drawCircle(6f, 2f, 27f, pat);
                break;
            case 8:
                pat.setColor(0xFFFF8FB5);
                pat.setStrokeWidth(2.5f);
                c.drawLine(-22f, -8f, 0f, -26f, pat);
                c.drawLine(0f, -26f, 22f, -8f, pat);
                c.drawLine(-22f, -8f, 0f, 4f, pat);
                c.drawLine(22f, -8f, 0f, 4f, pat);
                c.drawLine(0f, -26f, 0f, 4f, pat);
                c.drawLine(-14f, 24f, 0f, 4f, pat);
                c.drawLine(14f, 24f, 0f, 4f, pat);
                sparkle(c, 12f, -14f, 5f, 0xFFFFFFFF);
                break;
            case 9:
                dp.reset();
                for (float t = 0f; t < 14f; t += 0.4f) {
                    float r = 24f * t / 14f;
                    float px = (float) Math.cos(t) * r, py = (float) Math.sin(t) * r;
                    if (t == 0f) dp.moveTo(px, py); else dp.lineTo(px, py);
                }
                pat.setColor(0xFF2E9E6B);
                c.drawPath(dp, pat);
                break;
            case 10:
                pat.setColor(0xFFD99A00);
                pat.setStrokeWidth(3.5f);
                c.drawLine(-22f, 8f, -4f, 24f, pat);
                c.drawLine(10f, -24f, 24f, -6f, pat);
                c.drawLine(-26f, -4f, -14f, 4f, pat);
                sparkle(c, -10f, -12f, 5f + 3f * (float) Math.sin(time * 5f), 0xFFFFFFFF);
                break;
            case 11:
                dp.reset();
                dp.moveTo(-22f, 28f);
                dp.lineTo(-14f, -4f);
                dp.lineTo(-5f, 28f);
                dp.moveTo(-8f, 28f);
                dp.lineTo(2f, -14f);
                dp.lineTo(12f, 28f);
                dp.moveTo(10f, 28f);
                dp.lineTo(18f, 2f);
                dp.lineTo(26f, 28f);
                fill.setColor(0xFF9B6BE8);
                c.drawPath(dp, fill);
                pat.setColor(0xFF5B34A0);
                c.drawPath(dp, pat);
                break;
            case 12:
                fill.setColor(0x558A5CFF);
                c.drawCircle(-6f, -6f, 16f, fill);
                fill.setColor(0x55FF6FB5);
                c.drawCircle(8f, 8f, 14f, fill);
                fill.setColor(0xFFFFFFFF);
                c.drawCircle(-14f, -12f, 1.8f, fill);
                c.drawCircle(10f, -16f, 2.2f, fill);
                c.drawCircle(16f, 4f, 1.6f, fill);
                c.drawCircle(-6f, 10f, 2f, fill);
                c.drawCircle(-18f, 18f, 1.5f, fill);
                c.drawCircle(4f, 22f, 1.8f, fill);
                c.drawCircle(-2f, -4f, 1.4f, fill);
                sparkle(c, 12f, -6f, 3f + 2f * (float) Math.sin(time * 4f), 0xFFFFFFFF);
                break;
            case 13:
                hsv[0] = ((time * 70f) + 120f) % 360f;
                hsv[1] = 0.6f;
                hsv[2] = 1f;
                fill.setColor(Color.HSVToColor(170, hsv));
                c.drawCircle(-8f, -6f, 13f, fill);
                hsv[0] = ((time * 70f) + 220f) % 360f;
                fill.setColor(Color.HSVToColor(170, hsv));
                c.drawCircle(8f, 8f, 11f, fill);
                pat.setColor(0xCCFFFFFF);
                c.drawLine(-20f, 12f, -8f, 24f, pat);
                break;
            default:
                dp.reset();
                dp.moveTo(-12f, -16f);
                dp.lineTo(12f, -16f);
                dp.lineTo(24f, -2f);
                dp.lineTo(0f, 26f);
                dp.lineTo(-24f, -2f);
                dp.close();
                pat.setColor(0xFF7FC8E8);
                pat.setStrokeWidth(2.5f);
                c.drawPath(dp, pat);
                c.drawLine(-24f, -2f, 24f, -2f, pat);
                c.drawLine(-12f, -16f, -6f, -2f, pat);
                c.drawLine(-6f, -2f, 0f, 26f, pat);
                c.drawLine(12f, -16f, 6f, -2f, pat);
                c.drawLine(6f, -2f, 0f, 26f, pat);
                sparkle(c, 14f, -12f, 4f + 2f * (float) Math.sin(time * 6f), 0xFFFFFFFF);
                break;
        }
        pat.setStrokeWidth(3f);
    }

    void drawFace(Canvas c, int sk, float lookX, float lookY, boolean open) {
        int fc = isDark(sk) ? 0xFFFFFFFF : INK;
        float eh = ((time % 3.2f) < 0.12f) ? 0.15f : 1f;
        fill.setColor(fc);
        rect.set(-10f + lookX - 4.5f, -4f + lookY - 4.5f * eh, -10f + lookX + 4.5f, -4f + lookY + 4.5f * eh);
        c.drawOval(rect, fill);
        rect.set(10f + lookX - 4.5f, -4f + lookY - 4.5f * eh, 10f + lookX + 4.5f, -4f + lookY + 4.5f * eh);
        c.drawOval(rect, fill);
        pat.setColor(fc);
        pat.setStrokeWidth(2.5f);
        if (open) {
            c.drawCircle(lookX * 0.5f, 10f, 4f, pat);
        } else {
            rect.set(-6f + lookX * 0.5f, 5f, 6f + lookX * 0.5f, 14f);
            c.drawArc(rect, 20f, 140f, false, pat);
        }
        pat.setColor(0xCCFFFFFF);
        rect.set(-R * 0.62f, -R * 0.62f, R * 0.1f, R * 0.1f);
        c.drawArc(rect, 200f, 70f, false, pat);
        pat.setStrokeWidth(3f);
    }

    void drawBall(Canvas c) {
        float sy = 1f - squash * 0.28f + Math.min(0.22f, Math.abs(bvy) / 5500f);
        float sx = 1f + squash * 0.28f - Math.min(0.12f, Math.abs(bvy) / 9000f);
        c.save();
        c.translate(bx, by + R * (1f - sy));
        c.scale(sx, sy);
        drawStone(c, skin, bAngle);
        float lookX = Math.max(-4f, Math.min(4f, bvx / 120f));
        float lookY = Math.max(-3f, Math.min(3f, bvy / 300f));
        drawFace(c, skin, lookX, lookY, squash > 0.4f || by > H * 0.78f);
        c.restore();
    }

    void drawParticles(Canvas c) {
        for (Particle p : parts) {
            float a = p.life / p.max;
            fill.setColor((p.color & 0xFFFFFF) | (((int) (255 * a)) << 24));
            c.drawCircle(p.x, p.y, p.size * (0.4f + 0.6f * a), fill);
        }
    }

    // ------------------------------------------------------------- UI

    void drawHud(Canvas c) {
        text(c, ((int) (climbed / 40f)) + " m", 36f, 100f, 58f, INK, Paint.Align.LEFT);
        drawCoinShape(c, W - 44f, 82f, 18f, 1f);
        text(c, "" + coins, W - 72f, 100f, 58f, INK, Paint.Align.RIGHT);
    }

    void drawMenu(Canvas c) {
        float cx = W / 2f;
        float ty = H * 0.15f;
        c.save();
        c.rotate(-4f, cx, ty);
        text(c, "Stone", cx + 6f, ty + 6f, 128f, 0xFFFFB3C7, Paint.Align.CENTER);
        text(c, "Stone", cx, ty, 128f, INK, Paint.Align.CENTER);
        text(c, "Sphere", cx + 6f, ty + 132f, 128f, 0xFF9AD0FF, Paint.Align.CENTER);
        text(c, "Sphere", cx, ty + 126f, 128f, INK, Paint.Align.CENTER);
        dp.reset();
        for (int i = 0; i <= 16; i++) {
            float px = cx - 200f + i * 25f;
            float py = ty + 168f + ((i % 2 == 0) ? -7f : 7f);
            if (i == 0) dp.moveTo(px, py); else dp.lineTo(px, py);
        }
        c.drawPath(dp, ink);
        c.restore();

        drawButton(c, bPlay, "PLAY", 0xFFFFB3C7, 64f);
        drawButton(c, bStore, "STORE", 0xFFFFD966, 48f);
        drawButton(c, bSet, "SETTINGS", 0xFF9AD0FF, 48f);

        drawCoinShape(c, W - 44f, 70f, 18f, 1f);
        text(c, "" + totalCoins, W - 72f, 88f, 52f, INK, Paint.Align.RIGHT);
        text(c, "Best: " + best + " m", cx, H * 0.72f + 100f, 40f, INK, Paint.Align.CENTER);
    }

    void drawDead(Canvas c) {
        float a = Math.min(1f, deadTimer * 2.2f);
        fill.setColor(Color.argb((int) (190 * a), 255, 255, 255));
        c.drawRect(0, 0, W, H, fill);
        int ia = (int) (255 * a);
        int dark = Color.argb(ia, 35, 35, 58);
        float cx = W / 2f;
        c.save();
        c.rotate(-3f, cx, H * 0.26f);
        text(c, "Crumbled!", cx + 5f, H * 0.26f + 5f, 112f, Color.argb(ia, 255, 179, 199), Paint.Align.CENTER);
        text(c, "Crumbled!", cx, H * 0.26f, 112f, dark, Paint.Align.CENTER);
        c.restore();
        text(c, "Height: " + ((int) (climbed / 40f)) + " m", cx, H * 0.38f, 62f, dark, Paint.Align.CENTER);
        text(c, "Coins: +" + coins, cx, H * 0.38f + 70f, 52f, Color.argb(ia, 224, 161, 0), Paint.Align.CENTER);
        if (newBest) text(c, "NEW BEST!", cx, H * 0.38f + 140f, 56f, Color.argb(ia, 255, 107, 107), Paint.Align.CENTER);
        else text(c, "Best: " + best + " m", cx, H * 0.38f + 140f, 46f, dark, Paint.Align.CENTER);
        if (deadTimer > 0.6f) {
            float pz = 1f + 0.06f * (float) Math.sin(time * 4f);
            c.save();
            c.scale(pz, pz, cx, H * 0.62f);
            text(c, "Tap to retry", cx, H * 0.62f, 58f, dark, Paint.Align.CENTER);
            c.restore();
            drawButton(c, bMenu, "MENU", 0xFF9AD0FF, 46f);
        }
    }

    void drawStore(Canvas c) {
        fill.setColor(0xFFFFE9A8);
        rect.set(panel.left + 8f, panel.top + 8f, panel.right + 8f, panel.bottom + 8f);
        c.drawRoundRect(rect, 26f, 26f, fill);
        fill.setColor(0xFFFFFFFF);
        c.drawRoundRect(panel, 26f, 26f, fill);
        c.drawRoundRect(panel, 26f, 26f, ink);

        text(c, "STORE", panel.left + 46f, panel.top + 96f, 76f, 0xFFFFB3C7, Paint.Align.LEFT);
        text(c, "STORE", panel.left + 40f, panel.top + 90f, 76f, INK, Paint.Align.LEFT);
        float shk = coinShake > 0f ? (float) Math.sin(time * 60f) * 6f : 0f;
        drawCoinShape(c, panel.left + 58f + shk, panel.top + 138f, 18f, 1f);
        text(c, "" + totalCoins, panel.left + 90f + shk, panel.top + 154f, 48f,
                coinShake > 0f ? 0xFFFF5252 : INK, Paint.Align.LEFT);

        float gap = 24f;
        float cw = (panel.width() - 3f * gap) / 2f;
        c.save();
        c.clipRect(listR);
        for (int i = 0; i < S_NAME.length; i++) {
            float x = panel.left + gap + (i % 2) * (cw + gap);
            float y = listR.top + 10f + (i / 2) * (CARD_H + gap) - storeScroll;
            if (y + CARD_H + 10f < listR.top || y - 10f > listR.bottom) continue;
            drawCard(c, i, x, y, cw);
        }
        c.restore();

        // scrollbar
        float mx = maxScroll();
        if (mx > 0f) {
            float trackH = listR.height() - 20f;
            float barH = Math.max(50f, trackH * listR.height() / (listR.height() + mx));
            float barY = listR.top + 10f + (trackH - barH) * (storeScroll / mx);
            pat.setColor(0xFFC9CED8);
            pat.setStrokeWidth(6f);
            c.drawLine(panel.right - 12f, barY, panel.right - 12f, barY + barH, pat);
            pat.setStrokeWidth(3f);
        }

        drawClose(c, storeCX, storeCY);

        if (msgT > 0f) {
            float al = Math.min(1f, msgT * 2f);
            int ia = (int) (255 * al);
            rect.set(W / 2f - 240f, panel.bottom - 120f, W / 2f + 240f, panel.bottom - 50f);
            fill.setColor(Color.argb(ia, 35, 35, 58));
            c.drawRoundRect(rect, 30f, 30f, fill);
            text(c, msg, W / 2f, panel.bottom - 73f, 36f, Color.argb(ia, 255, 255, 255), Paint.Align.CENTER);
        }
    }

    void drawCard(Canvas c, int i, float x, float y, float w) {
        int col = skinColor(i);
        fill.setColor((col & 0xFFFFFF) | 0x66000000);
        rect.set(x, y, x + w, y + CARD_H);
        c.drawRoundRect(rect, 22f, 22f, fill);
        if (i == skin) {
            ink.setColor(0xFF2E9E6B);
            ink.setStrokeWidth(8f);
            c.drawRoundRect(rect, 22f, 22f, ink);
            ink.setColor(INK);
            ink.setStrokeWidth(5f);
        } else {
            c.drawRoundRect(rect, 22f, 22f, ink);
        }

        c.save();
        c.translate(x + w / 2f, y + 112f);
        float k = 62f / R;
        c.scale(k, k);
        drawStone(c, i, time * 0.6f * ((i % 2 == 0) ? 1f : -1f));
        drawFace(c, i, (float) Math.sin(time * 2f + i) * 3f, 0f, false);
        c.restore();

        text(c, S_NAME[i], x + w / 2f, y + 218f, 34f, INK, Paint.Align.CENTER);

        tmpR.set(x + 20f, y + CARD_H - 86f, x + w - 20f, y + CARD_H - 22f);
        if (i == skin) {
            drawButton(c, tmpR, "Equipped", 0xFF9EE6B8, 32f);
        } else if (owned(i)) {
            drawButton(c, tmpR, "Equip", 0xFF9AD0FF, 34f);
        } else {
            boolean can = totalCoins >= S_PRICE[i];
            drawButton(c, tmpR, "", can ? 0xFFFFD966 : 0xFFE3E5EC, 34f);
            String ps = "" + S_PRICE[i];
            textP.setTextSize(36f);
            float tw = textP.measureText(ps);
            float total = 32f + 8f + tw;
            float start = tmpR.centerX() - total / 2f;
            drawCoinShape(c, start + 14f, tmpR.centerY(), 14f, 1f);
            text(c, ps, start + 40f, tmpR.centerY() + 13f, 36f, can ? INK : 0xFF9A9FB0, Paint.Align.LEFT);
        }
    }

    void drawSettings(Canvas c) {
        fill.setColor(Color.argb(120, 35, 35, 58));
        c.drawRect(0, 0, W, H, fill);
        fill.setColor(0xFF9AD0FF);
        rect.set(popup.left + 8f, popup.top + 8f, popup.right + 8f, popup.bottom + 8f);
        c.drawRoundRect(rect, 28f, 28f, fill);
        fill.setColor(0xFFFFFFFF);
        c.drawRoundRect(popup, 28f, 28f, fill);
        c.drawRoundRect(popup, 28f, 28f, ink);

        text(c, "Settings", popup.centerX(), popup.top + 96f, 66f, INK, Paint.Align.CENTER);
        text(c, "Music", popup.left + 50f, popup.top + 196f, 46f, INK, Paint.Align.LEFT);
        String vs = vol <= 0.001f ? "Off" : ((int) (vol * 100f + 0.5f)) + "%";
        text(c, vs, popup.right - 50f, popup.top + 196f, 46f, INK, Paint.Align.RIGHT);

        ink.setStrokeWidth(18f);
        c.drawLine(sliderL, sliderY, sliderR, sliderY, ink);
        ink.setStrokeWidth(5f);
        pat.setStrokeWidth(11f);
        pat.setColor(0xFFF1F2F7);
        c.drawLine(sliderL, sliderY, sliderR, sliderY, pat);
        float kx = sliderL + vol * (sliderR - sliderL);
        if (vol > 0.01f) {
            pat.setColor(0xFFFFB3C7);
            c.drawLine(sliderL, sliderY, kx, sliderY, pat);
        }
        pat.setStrokeWidth(3f);
        fill.setColor(0xFFFFD966);
        c.drawCircle(kx, sliderY, 26f, fill);
        c.drawCircle(kx, sliderY, 26f, ink);

        text(c, "Drag to change volume", popup.centerX(), popup.bottom - 40f, 30f, 0xFF6B6F85, Paint.Align.CENTER);
        drawClose(c, closeSX, closeSY);
    }
}